Writing a full tutorial for Nmap, including all options, would be quite extensive. However, I can provide you with a comprehensive overview and some of the most commonly used options to get you started.

### What is Nmap?
Nmap, short for Network Mapper, is a powerful open-source network scanning tool used for network discovery and security auditing. It allows users to discover hosts and services on a computer network, thus creating a map of the network. Nmap is available for various platforms including Windows, Linux, and macOS.

### Basic Usage:
The basic syntax of Nmap is:
```
nmap [Scan Type(s)] [Options] {target specification}
```

### Common Scan Types:
1. **TCP Connect Scan (-sT):** This is the most basic form of TCP scanning. It sends a TCP connection request to the target and listens for a response to determine whether the port is open.
2. **SYN Stealth Scan (-sS):** Also known as a half-open scan, this method is more stealthy than the TCP connect scan as it doesn't establish a full connection.
3. **UDP Scan (-sU):** Used to scan UDP ports. UDP scans are slower and less reliable than TCP scans.
4. **Ping Scan (-sP):** Also known as a ping sweep, this scan type is used to discover live hosts on a network without scanning specific ports.

### Common Options:
1. **-p <port range>:** Specifies which ports to scan. You can specify a single port, a range of ports (e.g., 1-100), or a combination of both.
2. **-A:** Enables OS detection, version detection, script scanning, and traceroute.
3. **-O:** Enables OS detection to attempt to determine the operating system of the target.
4. **-sV:** Attempts to determine the version of the services running on the ports.
5. **-T <timing template>:** Specifies the timing template to use for the scan. Options are paranoid, sneaky, polite, normal, aggressive, and insane.
6. **-oN <file>:** Saves the output in normal format to the specified file.
7. **-oX <file>:** Saves the output in XML format to the specified file.
8. **-v:** Increases verbosity level. Can be used multiple times for increased verbosity.

### Examples:
1. Perform a SYN Stealth Scan on a target:
```
nmap -sS <target>
```

2. Perform a TCP Connect Scan on a range of ports:
```
nmap -sT -p 1-100 <target>
```

3. Perform an aggressive scan with OS and version detection:
```
nmap -A <target>
```

4. Perform a UDP Scan on a target:
```
nmap -sU <target>
```

Remember, always ensure you have proper authorization before scanning any network, as unauthorized scanning may be illegal and unethical. Additionally, some scan types may be detected by intrusion detection systems and can result in network disruption or legal consequences.